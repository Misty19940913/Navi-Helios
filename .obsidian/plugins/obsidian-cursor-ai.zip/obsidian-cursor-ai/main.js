/* 
  Generated JS for Obsidian Cursor AI 
  Standard CommonJS format for Obsidian Plugins
*/

const { Plugin, ItemView, WorkspaceLeaf, MarkdownView, PluginSettingTab, Setting, Notice, requestUrl } = require('obsidian');

const VIEW_TYPE_CURSOR = "cursor-ai-view";

const DEFAULT_SETTINGS = {
    apiUrl: 'https://api.openai.com/v1/chat/completions',
    apiKey: '',
    model: 'gpt-3.5-turbo',
    systemRole: 'You are an expert AI assistant for Obsidian. You are helpful, concise, and expert in Markdown.'
};

class CursorAIView extends ItemView {
    constructor(leaf, plugin) {
        super(leaf);
        this.plugin = plugin;
    }

    getViewType() {
        return VIEW_TYPE_CURSOR;
    }

    getDisplayText() {
        return "Cursor AI Chat";
    }

    async onOpen() {
        const container = this.containerEl.children[1];
        container.empty();
        container.addClass('cursor-ai-container');

        // Chat History Area
        this.chatContainer = container.createDiv({ cls: 'cursor-chat-history' });

        // Input Area
        const inputArea = container.createDiv({ cls: 'cursor-input-area' });
        this.inputEl = inputArea.createEl('textarea', {
            cls: 'cursor-chat-input',
            attr: { placeholder: 'Ask AI or type instructions to edit file...' }
        });

        const sendBtn = inputArea.createEl('button', { text: 'Send', cls: 'cursor-send-btn' });
        sendBtn.addEventListener('click', () => this.handleSend());
        
        // Allow Ctrl+Enter to send
        this.inputEl.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
                e.preventDefault();
                this.handleSend();
            }
        });
    }

    async handleSend() {
        const userInput = this.inputEl.value.trim();
        if (!userInput) return;

        // 1. Display User Message
        this.appendMessage(userInput, 'user');
        this.inputEl.value = '';

        // 2. Gather Context (Active File)
        let context = "";
        const activeView = this.app.workspace.getActiveViewOfType(MarkdownView);
        if (activeView) {
            context = activeView.editor.getValue();
        }

        // 3. Prepare Payload
        const messages = [
            { role: 'system', content: this.plugin.settings.systemRole },
            { 
                role: 'user', 
                content: `Active File Content:\n\n\`\`\`markdown\n${context}\n\`\`\`\n\nUser Instruction: ${userInput}` 
            }
        ];

        // 4. Call API
        try {
            const loadingMsg = this.appendMessage('Thinking...', 'ai', true);
            
            const response = await requestUrl({
                url: this.plugin.settings.apiUrl,
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.plugin.settings.apiKey}`
                },
                body: JSON.stringify({
                    model: this.plugin.settings.model,
                    messages: messages,
                    temperature: 0.7
                })
            });

            const data = response.json;
            const aiText = data.choices && data.choices[0] ? data.choices[0].message.content : "Error: No response";

            // Remove loading, add real message
            loadingMsg.remove();
            this.appendMessage(aiText, 'ai');

        } catch (err) {
            new Notice('Cursor AI Error: ' + err.message);
            this.appendMessage('Error: ' + err.message, 'ai');
        }
    }

    appendMessage(text, role, isLoading = false) {
        const msgDiv = this.chatContainer.createDiv({ cls: `cursor-msg ${role}-msg` });
        
        // Render Markdown (basic)
        MarkdownView.renderMarkdown(text, msgDiv, '', this.plugin);

        if (role === 'ai' && !isLoading) {
            // Add "Apply to Editor" button
            const actionsDiv = msgDiv.createDiv({ cls: 'cursor-msg-actions' });
            const applyBtn = actionsDiv.createEl('button', { text: 'Insert at Cursor', cls: 'cursor-action-btn' });
            
            applyBtn.addEventListener('click', () => {
                const view = this.app.workspace.getActiveViewOfType(MarkdownView);
                if (view) {
                    view.editor.replaceSelection(text);
                    new Notice('Content inserted!');
                } else {
                    new Notice('No active markdown file.');
                }
            });
        }

        this.chatContainer.scrollTop = this.chatContainer.scrollHeight;
        return msgDiv;
    }

    async onClose() {
        // Cleanup if needed
    }
}

class CursorAISettingTab extends PluginSettingTab {
    constructor(app, plugin) {
        super(app, plugin);
        this.plugin = plugin;
    }

    display() {
        const { containerEl } = this;
        containerEl.empty();

        containerEl.createEl('h2', { text: 'Cursor AI Settings' });

        new Setting(containerEl)
            .setName('API URL')
            .setDesc('Endpoint URL (e.g., https://api.openai.com/v1/chat/completions)')
            .addText(text => text
                .setPlaceholder('https://api.openai.com/v1/chat/completions')
                .setValue(this.plugin.settings.apiUrl)
                .onChange(async (value) => {
                    this.plugin.settings.apiUrl = value;
                    await this.plugin.saveSettings();
                }));

        new Setting(containerEl)
            .setName('API Key')
            .setDesc('Your API Key')
            .addText(text => text
                .setPlaceholder('sk-...')
                .setValue(this.plugin.settings.apiKey)
                .onChange(async (value) => {
                    this.plugin.settings.apiKey = value;
                    await this.plugin.saveSettings();
                }));

        new Setting(containerEl)
            .setName('Model Name')
            .setDesc('The model ID to use (e.g., gpt-4, claude-3, llama3)')
            .addText(text => text
                .setPlaceholder('gpt-3.5-turbo')
                .setValue(this.plugin.settings.model)
                .onChange(async (value) => {
                    this.plugin.settings.model = value;
                    await this.plugin.saveSettings();
                }));

        new Setting(containerEl)
            .setName('System Role (Rules)')
            .setDesc('Define the persona and rules for the AI.')
            .addTextArea(text => text
                .setPlaceholder('You are a helpful assistant...')
                .setValue(this.plugin.settings.systemRole)
                .onChange(async (value) => {
                    this.plugin.settings.systemRole = value;
                    await this.plugin.saveSettings();
                }));
    }
}

module.exports = class CursorAIPlugin extends Plugin {
    async onload() {
        await this.loadSettings();

        this.registerView(
            VIEW_TYPE_CURSOR,
            (leaf) => new CursorAIView(leaf, this)
        );

        this.addRibbonIcon('bot', 'Cursor AI Chat', () => {
            this.activateView();
        });

        this.addCommand({
            id: 'open-cursor-ai-chat',
            name: 'Open AI Chat',
            callback: () => {
                this.activateView();
            }
        });

        this.addSettingTab(new CursorAISettingTab(this.app, this));
    }

    async activateView() {
        const { workspace } = this.app;
        let leaf = null;
        const leaves = workspace.getLeavesOfType(VIEW_TYPE_CURSOR);

        if (leaves.length > 0) {
            leaf = leaves[0];
        } else {
            leaf = workspace.getRightLeaf(false);
            await leaf.setViewState({ type: VIEW_TYPE_CURSOR, active: true });
        }

        if (leaf) workspace.revealLeaf(leaf);
    }

    async loadSettings() {
        this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
    }

    async saveSettings() {
        await this.saveData(this.settings);
    }
};